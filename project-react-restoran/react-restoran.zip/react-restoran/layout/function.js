// File: function.js
// Berisi berbagai fungsi utilitas atau umum

function showMessage(message) {
  console.log(message);
  alert(message);
}

function calculateSum(a, b) {
  return a + b;
}

// Contoh penggunaan:
// showMessage('Halo dari function.js!');
// const total = calculateSum(10, 5);
// console.log('Hasil penjumlahan:', total);